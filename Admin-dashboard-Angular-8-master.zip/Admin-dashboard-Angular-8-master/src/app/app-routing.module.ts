import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './screens/home/home.component';
import { ButtonsComponent } from './screens/buttons/buttons.component';
import { CardsComponent } from './screens/cards/cards.component';
import { ColorComponent } from './screens/color/color.component';
import { BordersComponent } from './screens/borders/borders.component';
import { AnimationComponent } from './screens/animation/animation.component';
import { Page404Component } from './screens/page404/page404.component';
import { ForgotPasswordComponent } from './screens/forgot-password/forgot-password.component';
import { RegisterComponent } from './screens/register/register.component';
import { LoginComponent } from './screens/login/login.component';
import { ChartsComponent } from './screens/charts/charts.component';
import { TablesComponent } from './screens/tables/tables.component';

import { IconComponent } from './screens/icon/icon.component';
import { BrandComponent } from './screens/brand/brand.component';
import { CircleIconComponent } from './screens/circle-icon/circle-icon.component';
import { DefaultComponent } from './screens/default/default.component';
import { CustomComponent } from './screens/custom/custom.component';
import { BorderUtilitesComponent } from './screens/border-utilites/border-utilites.component';
import { AnimationUtilitiesComponent } from './screens/animation-utilities/animation-utilities.component';
import { OtherComponent } from './screens/other/other.component';
import { OtherUtilitiesComponent } from './screens/other-utilities/other-utilities.component';







const routes: Routes = [{
  path: '', component: HomeComponent
},

{
  path: 'button', component: ButtonsComponent
},

{
  path: 'card', component: CardsComponent
},

{
  path: 'color', component: ColorComponent
},
{
  path: 'border', component: BordersComponent
},

{
  path: 'animation', component: AnimationComponent
},



{
  path: 'login', component: LoginComponent
},

{
  path: 'register', component: RegisterComponent
},
{
  path: 'forgot-password', component: ForgotPasswordComponent
},

{
  path: 'page404', component: Page404Component
},
{
  path: 'charts', component: ChartsComponent
},
{
  path: 'tables', component: TablesComponent
},



{
  path: 'icon', component: IconComponent
},

{
  path: 'brand', component: BrandComponent
},

{
  path: 'circle-icon', component: CircleIconComponent
},

{
  path: 'default', component: DefaultComponent
},

{
  path: 'custom', component: CustomComponent
},

{
  path: 'border-utilites', component: BorderUtilitesComponent
},

{
  path: 'animation-utilites', component: AnimationUtilitiesComponent
},

{
  path: 'other', component: OtherComponent
},

{
  path: 'other-utilities', component: OtherUtilitiesComponent
},






];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
