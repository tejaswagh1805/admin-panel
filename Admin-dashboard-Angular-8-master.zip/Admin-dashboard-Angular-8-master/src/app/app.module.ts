import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ChartsModule } from 'ng2-charts';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { HeaderComponent } from './components/header/header.component';
import { ContentComponent } from './components/content/content.component';
import { HomeComponent } from './screens/home/home.component';
import { DevelopComponent } from './components/develop/develop.component';
import { MonthlyComponent } from './components/monthly/monthly.component';
import { AnnualComponent } from './components/annual/annual.component';
import { TasksComponent } from './components/tasks/tasks.component';
import { CardComponent } from './components/card/card.component';
import { ProjectsComponent } from './components/projects/projects.component';
import { PrimaryComponent } from './components/primary/primary.component';
import { SourcesComponent } from './components/sources/sources.component';
import { ApproachComponent } from './components/approach/approach.component';
import { ButtonsComponent } from './screens/buttons/buttons.component';
import { CardsComponent } from './screens/cards/cards.component';
import { ColorComponent } from './screens/color/color.component';
import { BordersComponent } from './screens/borders/borders.component';
import { AnimationComponent } from './screens/animation/animation.component';
import { LoginComponent } from './screens/login/login.component';
import { RegisterComponent } from './screens/register/register.component';
import { ForgotPasswordComponent } from './screens/forgot-password/forgot-password.component';
import { Page404Component } from './screens/page404/page404.component';
import { ChartsComponent } from './screens/charts/charts.component';
import { TablesComponent } from './screens/tables/tables.component';

import { IconComponent } from './screens/icon/icon.component';
import { BrandComponent } from './screens/brand/brand.component';
import { CircleIconComponent } from './screens/circle-icon/circle-icon.component';
import { DefaultComponent } from './screens/default/default.component';
import { CustomComponent } from './screens/custom/custom.component';
import { BorderUtilitesComponent } from './screens/border-utilites/border-utilites.component';
import { AnimationUtilitiesComponent } from './screens/animation-utilities/animation-utilities.component';
import { OtherComponent } from './screens/other/other.component';
import { OtherUtilitiesComponent } from './screens/other-utilities/other-utilities.component';
import { ChartUtilitiesComponent } from './screens/chart-utilities/chart-utilities.component';
import { LineChartComponent } from './components/line-chart/line-chart.component';
import { BlockCardComponent } from './components/block-card/block-card.component';
import { PieChartComponent } from './components/pie-chart/pie-chart.component';
import { PieCardComponent } from './components/pie-card/pie-card.component';
import { BarChartComponent } from './components/bar-chart/bar-chart.component';
import { BarCardComponent } from './components/bar-card/bar-card.component';
import { DoughnutChartComponent } from './components/doughnut-chart/doughnut-chart.component';
import { DoughnutCardComponent } from './components/doughnut-card/doughnut-card.component';










@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    HeaderComponent,
    ContentComponent,
    HomeComponent,
    DevelopComponent,
    MonthlyComponent,
    AnnualComponent,
    TasksComponent,
    CardComponent,
    ProjectsComponent,
    PrimaryComponent,
    SourcesComponent,
    ApproachComponent,
    ButtonsComponent,
    CardsComponent,
    ColorComponent,
    BordersComponent,
    AnimationComponent,
    LoginComponent,
    RegisterComponent,
    ForgotPasswordComponent,
    Page404Component,
    ChartsComponent,
    TablesComponent,
    IconComponent,
    BrandComponent,
    CircleIconComponent,
    DefaultComponent,
    CustomComponent,
    BorderUtilitesComponent,
    AnimationUtilitiesComponent,
    OtherComponent,
    OtherUtilitiesComponent,
    ChartUtilitiesComponent,
    LineChartComponent,
    BlockCardComponent,
    PieChartComponent,
    PieCardComponent,
    BarChartComponent,
    BarCardComponent,
    DoughnutChartComponent,
    DoughnutCardComponent,
  

  ],
 imports: [
    BrowserModule,
    AppRoutingModule,
    ChartsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }