import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimationUtilitiesComponent } from './animation-utilities.component';

describe('AnimationUtilitiesComponent', () => {
  let component: AnimationUtilitiesComponent;
  let fixture: ComponentFixture<AnimationUtilitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnimationUtilitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnimationUtilitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
