import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-animation-utilities',
  templateUrl: './animation-utilities.component.html',
  styleUrls: ['./animation-utilities.component.scss']
})
export class AnimationUtilitiesComponent implements OnInit {
  @Input () title: string;
  

  constructor() { }

  ngOnInit() {
  }

}
