import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BorderUtilitesComponent } from './border-utilites.component';

describe('BorderUtilitesComponent', () => {
  let component: BorderUtilitesComponent;
  let fixture: ComponentFixture<BorderUtilitesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BorderUtilitesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BorderUtilitesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
