import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-border-utilites',
  templateUrl: './border-utilites.component.html',
  styleUrls: ['./border-utilites.component.scss']
})
export class BorderUtilitesComponent implements OnInit {
  @Input() title: String;

  constructor() { }

  ngOnInit() {
  }

}
