import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buttons',
  templateUrl: './buttons.component.html',
  styleUrls: ['./buttons.component.scss']
})
export class ButtonsComponent implements OnInit {

  
// circle: any =  {
//   name: "Circle",
//   body: 'FDJKDHVJDFVSDFKVKD',
// };
// Brand: any ={
//   name: "brand",
//   body: 'dsbfdsjvbcdjcjks'
// }
  content = "Use Font Awesome Icons (included with this theme package) along with the circle buttons as shown in the examples below!";
  contentBrand = "Google and Facebook buttons are available featuring each company's respective brand color. They are used on the user login and registration pages. You can create more custom buttons by adding a new color variable in the _variables.scss file and then using the Bootstrap button variant mixin to create a new style, as demonstrated in the _buttons.scss file.";
  constructor() {
   }

  ngOnInit() {
  }

}


