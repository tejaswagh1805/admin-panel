import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChartUtilitiesComponent } from './chart-utilities.component';

describe('ChartUtilitiesComponent', () => {
  let component: ChartUtilitiesComponent;
  let fixture: ComponentFixture<ChartUtilitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChartUtilitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartUtilitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
