import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-chart-utilities',
  templateUrl: './chart-utilities.component.html',
  styleUrls: ['./chart-utilities.component.scss']
})
export class ChartUtilitiesComponent implements OnInit {
  @Input () title: string;

  constructor() { }

  ngOnInit() {
  }

}
