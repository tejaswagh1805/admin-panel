import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-custom',
  templateUrl: './custom.component.html',
  styleUrls: ['./custom.component.scss']
})
export class CustomComponent implements OnInit {
  @Input() title: String;

  constructor() { }

  ngOnInit() {
  }

}
