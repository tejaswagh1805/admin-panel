import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherUtilitiesComponent } from './other-utilities.component';

describe('OtherUtilitiesComponent', () => {
  let component: OtherUtilitiesComponent;
  let fixture: ComponentFixture<OtherUtilitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherUtilitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherUtilitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
