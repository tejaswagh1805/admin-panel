import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-other-utilities',
  templateUrl: './other-utilities.component.html',
  styleUrls: ['./other-utilities.component.scss']
})
export class OtherUtilitiesComponent implements OnInit {
  @Input () title: string;
  

  constructor() { }

  ngOnInit() {
  }

}
